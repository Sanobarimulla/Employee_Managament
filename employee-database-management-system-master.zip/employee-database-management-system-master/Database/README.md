This folder contains the bacpac file of the database used for this project. Import this file in MS SQL Server 2017 in order to use it.

![ER Diagram](https://drive.google.com/uc?export=view&id=1MQlL08VN8kTu7w8cjYKYh_vRH8W51Ww2)
