This is a windows forms application used to maintain and manage the company, department and employee details.


**Steps to run this project on your end system**
1. Install Visual Studio 2019 application and MS Sql server 2017 or 2019
2. Extract the database file and import it into sql server management studio
3. Clone this project in Visual Studio
4. Obtain the Connection string to the database on the your device
5. Replace the 'ConnectionString' variable value to the connection string you just obtained at every occurance in all the files

**All set to run the project**
